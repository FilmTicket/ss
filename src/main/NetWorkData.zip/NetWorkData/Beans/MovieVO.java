package Beans;

/**
 * Created by Chen on 2017/6/7.
 */
public class MovieVO {
    private Integer status;
    private MovieData data;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public MovieData getData() {
        return data;
    }

    public void setData(MovieData data) {
        this.data = data;
    }
}
